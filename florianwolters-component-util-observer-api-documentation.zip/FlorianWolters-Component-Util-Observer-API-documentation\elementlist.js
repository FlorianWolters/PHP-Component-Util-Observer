
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Util\\Observer\\ChangeableSubjectInterface"],["c","FlorianWolters\\Component\\Util\\Observer\\ChangeableSubjectTrait"],["c","FlorianWolters\\Component\\Util\\Observer\\ObserverInterface"],["c","FlorianWolters\\Component\\Util\\Observer\\SubjectInterface"],["c","FlorianWolters\\Component\\Util\\Observer\\SubjectTrait"]];
